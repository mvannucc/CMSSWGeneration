#include "GeneratorInterface/Pythia8Interface/interface/CustomHook.h"

EDM_REGISTER_PLUGINFACTORY(CustomHookFactory, "CustomHookFactory");
